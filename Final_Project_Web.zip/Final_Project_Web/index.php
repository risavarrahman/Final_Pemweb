<?php 
  require "koneksi.php";
  session_start();

  if (isset($_GET['pesan'])) {
    if ($_GET['pesan'] == "gagal") {
      echo "<script>alert('Gagal Masuk! Username / Kata Sandi Salah!');</script>";
    } else if($_GET['pesan'] == "keluar") {
      echo "<script>alert('Anda Telah Berhasil Keluar!');</script>";
    } else if($_GET['pesan'] == "belum_login") {
      echo "<script>alert('Dimohon Login Terlebih dahulu!');</script>";
    } else if($_GET['pesan'] == "masuk") {
      echo "<script>alert('Selamat Datang');</script>";
    }
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>SAVE MONEY</title>
  <link rel="stylesheet" href="css/styleidx.css">
</head>
<body>
  <div class="bg">
    <div class="form-box">
      <div class="button-box">
        <div id="btn"></div>
          <button type="button" class="toggle-btn" onclick="login()">Masuk</button>
          <button type="button" class="toggle-btn" onclick="daftar()">Daftar</button>
      </div>
      
      <!-- Form Masuk -->
      <form id="login" class="input-group" action="loginact.php" method="POST">
        <input type="text" class="input-field" id="username" name="username" placeholder="Username" required autofocus>
        <input type="password" class="input-field" id="pass" name="pass" placeholder="Kata Sandi" required>
        <br><br>        
        <button type="submit" class="submit-btn" name="masuk">Masuk</button>
      </form>

      <!-- Form Daftar -->
      <form id="daftar" class="input-group" action="daftaract.php" method="POST">
        <input type="text" class="input-field" id="username" name="username" placeholder="Username" required autofocus>
        <input type="password" class="input-field" id="pass" name="pass" placeholder="Kata Sandi" required>
        <input type="text" class="input-field" id="nama" name="nama" placeholder="Nama Lengkap" required>        
        <input type="email" class="input-field" id="email" name="email" placeholder="Email" required>
        <input type="text" class="input-field" id="nomor_telp" name="nomor_telp" placeholder="Nomor Telepon" required>
        <br><br>
        <button type="submit" class="submit-btn" name="daftar">Daftar</button>
      </form>
    </div>
  </div>



  <script>
    var x = document.getElementById("login");
    var y = document.getElementById("daftar");
    var z = document.getElementById("btn");

    function daftar() {
      x.style.left = "-400px";
      y.style.left = "50px";
      z.style.left = "100px";
    }

    function login() {
      x.style.left = "50px";
      y.style.left = "450px";
      z.style.left = "0px";
    }
  </script>

</body>
</html>