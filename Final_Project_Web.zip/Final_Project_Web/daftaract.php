<?php 

  require "koneksi.php";
  ob_start();
  session_start();
  
  $username = strtolower(stripslashes($_POST['username']));
  $pass = mysqli_real_escape_string($koneksi, $_POST['pass']);
  $nama = $_POST['nama'];
  $email = $_POST['email'];
  $nomor_telp = $_POST['nomor_telp'];

  $result = mysqli_query($koneksi, "SELECT username FROM tb_user WHERE username = '$username'");

  if (mysqli_fetch_assoc($result)) {
    echo "<script>
    alert('username sudah terdaftar');
    location.replace('index.php');
    </script>";
  } else {
    
    // enkripsi password
    // $pass = password_hash($pass, PASSWORD_DEFAULT);

    // insert ke database
    if(is_numeric($nomor_telp)){
      
      $sql = "INSERT INTO tb_user (username, pass, nama, email, nomor_telp)
      VALUES ('$username', '$pass', '$nama', '$email', '$nomor_telp')";
  
      mysqli_query($koneksi, $sql);
      if (mysqli_error($koneksi)) {
      } else {
        echo "<script>
        alert('Anda Berhasil Terdaftar');
        location.replace('index.php');
        </script>";
  
      }
    } else {
      echo "<script>
        alert('Anda Gagal Terdaftar');
        location.replace('index.php');
        </script>";
    }

  }
  
?>

  
