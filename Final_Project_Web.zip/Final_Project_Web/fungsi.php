<?php 
	require "koneksi.php";
	session_start();
	$id_user = $_SESSION['id_user'];

	function edit($data) {
		$username = htmlspecialchars($data['username']);
		$nama = htmlspecialchars($data['nama']);
		$email = htmlspecialchars($data['email']);
		$nomor_telp = htmlspecialchars($data['nomor_telp']);
		$gambar = htmlspecialchars($data['gambar']);

		// upload gambar
		$gambar = upload();
		if (!$gambar) {
			return false;
		}

		$sql = "UPDATE tb_user SET
		username = '$username', nama = '$nama', email = '$email', 
		nomor_telp = '$nomor_telp', gambar = '$gambar'";
		
		mysqli_query($koneksi, $sql);

		return mysqli_affected_rows($koneksi);

	}

	function upload(){
		$namaFile = $_FILES['gambar']['name'];
		$ukuranFile = $_FILES['gambar']['size'];
		$error = $_FILES['gambar']['error'];
		$tmpName = $_FILES['gambar']['tmp_name'];

		// cek apakah tidak ada foto yg diupload
		if ($error === 4) {
			echo "<script>
				alert('Pilih gambar terlebih dahulu');
			</script>";
			return false;
		}

		// cek hanya gambar yg diupload
		$ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
		$ekstensiGambar = explode('.', $namaFile);
		$ekstensiGambar = strtolower(end($ekstensiGambar));
		if (!in_array($ekstensiGambar, $ekstensiGambarValid)) {
			echo "<script>
				alert('Yang anda upload bukan gambar');
			</script>";
			return false;
		}

		// cek jika ukuran terlalu besar
		if($ukuranFile > 2000000){
			echo "<script>
				alert('Ukuran Gambar terlalu besar');
			</script>";
			return false;
		}

		// lolos semua cek, gambar siap diupload
		$namaFileBaru = uniqid();
		$namaFileBaru .= '.';
		$namaFileBaru .= $ekstensiGambar;
		

		move_uploaded_file($tmpName, 'img/'.$namaFileBaru);

		return $namaFileBaru;
	}

?>