<?php 
	require "koneksi.php";
	session_start();

	if (!isset($_SESSION['login'])) {
		echo "<script>
			alert('Dimohon Login Dahulu!');
		</script>";
		header("location:index.php?pesan=belum_login");
		exit;
	}
	if (isset($_GET['pesan'])) {
		if ($_GET['pesan'] == "gagal") {
			echo "<script>alert('Gagal Masuk! Username / Kata Sandi Salah!');</script>";
		} else if($_GET['pesan'] == "keluar") {
			echo "<script>alert('Anda Telah Berhasil Keluar!');</script>";
		} else if($_GET['pesan'] == "belum_login") {
			echo "<script>alert('Dimohon Login Terlebih dahulu!');</script>";
		} else if($_GET['pesan'] == "masuk") {
			echo "<script>alert('Selamat Datang');</script>";
		}
		exit;
	}
	
	$id_user = $_SESSION['id_user'];
	$username = $_SESSION['username'];
  $nama = $_SESSION['nama'];

	$sql = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE username='$username'");

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>SAVE MONEY</title>
  <link rel="stylesheet" href="css/styleadmin.css">

	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">

  <!-- GOOGLE FONTS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
  <input type="checkbox" id="check">
  <!-- Header Start -->
  <header>
    <label for="check">
      <i class="fas fa-bars" id="sidebar_btn"></i>
    </label>
    <div class="left_area">
      <h3>SAVE MONEY</h3>
    </div>
    <div class="right_area">
    <span class="tanggal"><?php date_default_timezone_set('Asia/Jakarta'); echo date("d F Y")."&nbsp; &nbsp; &nbsp;"; ?></span>
      <a href="logout.php" class="btn_keluar">Keluar</a>
    </div>
  </header>
  <!-- Header End -->

	<?php foreach($sql as $row) ?>
  <!-- Sidebar Start -->
  <div class="sidebar">
    <center>
      <img src="img/<?= $row['gambar']; ?>" class="profile_img" alt="">
      <h4><?= $nama; ?></h4>
    </center>
    
    <a href="admin.php"><i class="fas fa-desktop"></i><span>Beranda</span></a>
    <a href="masuk.php"><i class="fas fa-sign-in-alt"></i><span>Pemasukan</span></a>
    <a href="keluar.php"><i class="fas fa-sign-out-alt"></i><span>Pengeluaran</span></a>
    <a href="laporan.php"><i class="fas fa-folder-open"></i><span>Laporan</span></a>
    <a href="user.php"><i class="fas fa-user"></i><span>Pengguna</span></a>
  </div>
  <!-- Sidebar End -->

	<!-- FORM TAMBAH START -->
	<div class="wrapper">
		<div class="inner">
			<div class="row">
				<div class="panel panel-success">
					<div class="modal-header">
						<form action="#" method="post">
							<h4>Form Tambah Data</h4>
					</div>
					<div class="modal-body">
						<div class="form-group">
							<label style="font-weight: bold;">Tanggal Keluar</label>
							<input type="date" class="form-control" name="tgl_keluar" id="tgl_keluar" required>
						</div>
						<div class="form-group">
							<label style="font-weight: bold;">Deskripsi</label>
							<input type="text" class="form-control" name="desk_keluar" id="desk_keluar" 
							placeholder="Beli ATK" required>
						</div>
						<div class="form-group">
							<label style="font-weight: bold;">Jumlah</label>
							<input type="text" class="form-control" name="jml_keluar" id="jml_keluar" 
							placeholder="100000" required>
						</div>
					</div>
					<div class="modal-footer">
						<a href="keluar.php"><button type="button" class="btn btn-default">Batal</button></a>
						<button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
					</div>
					</form>

				</div>
			</div>
		</div>
	</div>
	<!-- FORM TAMBAH ENDs -->

<?php 
	if(isset($_POST['simpan'])) {
		$tgl  = $_POST['tgl_keluar'];
		$desk = $_POST['desk_keluar']; 
		$jml  = $_POST['jml_keluar'];
		 
		if (is_numeric($jml)) {
			$sql = mysqli_query($koneksi, "INSERT INTO tb_kas (status, tanggal, deskripsi, keluar, id_user)
			VALUES ('keluar', '$tgl', '$desk', '$jml', '$id_user')");

			if($sql) {
				echo "<script>
				alert('Data Berhasil Ditambahkan');
				location.replace('keluar.php');
				</script>";
				exit;
			}
		} else {
			echo "<script>alert('Kolom Jumlah Hanya boleh Angka!');</script>";
		}
	}


?>


</body>
</html>