<?php 
  session_start();
  $_SESSION['login'] = true;
  $_GET['pesan']="";

  require "koneksi.php";
  
  $username = $_POST['username'];
  $pass     = $_POST['pass'];

  // $nama = $_POST['nama'];
  // $email = $_POST['email'];
  // $nomor_telp = $_POST['nomor_telp'];

  // query cek username akun
  $result = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE 
    username='$username' AND pass='$pass'");

  $row = mysqli_fetch_assoc($result);
  $cek = mysqli_num_rows($result);
  
  if ($cek > 0) {
    $_SESSION['id_user'] = $row['id_user'];
    $_SESSION['username'] = $username;
    $_SESSION['nama'] = $row['nama'];
    $_SESSION['nomor_telp'] = $row['nomor_telp'];
    $_SESSION['email'] = $row['email'];

    

    header('location: admin.php?pesan=masuk');
    exit;
  } else {
    header('location: index.php?pesan=gagal');
  }

?>