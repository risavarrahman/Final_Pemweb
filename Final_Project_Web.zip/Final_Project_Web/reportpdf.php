<?php
	require "koneksi.php";
	session_start();
	$id_user = $_SESSION['id_user'];
	require_once("dompdf/autoload.inc.php");
	use Dompdf\Dompdf;

	$dompdf = new Dompdf();
	$sql = mysqli_query($koneksi, "SELECT * FROM tb_kas WHERE id_user='$id_user' ORDER BY tanggal");
	$html = '<hr><center><h3>Laporan Keuangan Perbulan</h3></center><hr/><br/>';
	$html .= '<table border="1" width="100%">
	<tr>
	<th>No. </th>
	<th>Tanggal Transaksi</th>
	<th>Deskripsi</th>
	<th>Jumlah Masuk</th>
	<th>Status</th>
	<th>Jumlah Keluar</th>
	</tr>';
	$no = 1;
	while ($row = mysqli_fetch_array($sql)) {
		$html .= "<tr>
		<td>".$no."</td>
		<td>".$row['tanggal']."</td>
		<td>".$row['deskripsi']."</td>
		<td>".$row['jumlah']."</td>
		<td>".$row['status']."</td>
		<td>".$row['keluar']."</td>
		</tr>";
		$no++;
	}

	$html .= "</html>";
	$dompdf ->loadHtml($html);

	// Setting ukuran dan orientasi kertas
	$dompdf ->setPaper('A3','landscape');

	// Rendering dari HTML ke PDF
	$dompdf ->render();

	// Melakukan output file Pdf
	$dompdf ->stream('laporan_keuangan_bulanan.pdf');
?>